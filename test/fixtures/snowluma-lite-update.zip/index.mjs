// SnowLuma lite (v2 fixture)
console.log('v2 build');
export {};
