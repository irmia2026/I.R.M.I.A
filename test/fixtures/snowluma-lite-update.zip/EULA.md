fixture eula v2 (fixture only, not the real EULA)
